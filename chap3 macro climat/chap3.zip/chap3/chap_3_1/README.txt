Ok ce dossier est un peu plus complexe que les autres modèles que l'on 
a fait tourner jusqu'à présent. 

L'ordre pour faire tourner les scripts est le suivant : 

1. main.m => il permet de faire l'ensemble des simulations

2.simualte_unantipacted_shock => permet de faire un choc non anticipé puis un 
 choc anticipé dans la même simulation

3. comparison.m => permet de comparer un choc anticipé et non anticipé à
la même période