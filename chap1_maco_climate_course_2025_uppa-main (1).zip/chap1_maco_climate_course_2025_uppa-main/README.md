# maco_climate_course_2025_uppa
Cours 2025 macro-climat. Codes dynare


Cours pour les M2 EIED 2025. 

Le cours se décompose en 3 chapitres. 

1. Prise en main rapide de la modélisation dynamique + écriture d'un modèle sous Dynare

2. Extensions du modèle RBC déterministe sous hypothèses de CPP avec travail exoxène vers un
   un modèle à travail endogène plus Etat (pas de climat dans le chapitre 2)

3. Introduction de la boucle économie -> climat puis de la boucle rétro active climat -> économie
