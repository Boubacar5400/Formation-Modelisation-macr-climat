# chap2_maco_climate_course_2025_uppa
Deuxième chapitre pour la modélisation macro climat pour les master 2 EIED 

On va repartir du modèle développé dans le chapitre 1 pour le complexifier. 

L'idée est de mettre l'ensemble des éléments nécessaires pour faire de la modélisation macro climat. 

On commencce par ajouter le travail exogène, comparer les chocs entre choc de productivité et choc d'offre de travail
cf dossier basic rbc2

On va ensuite rendre endogène le travail
cf chap2_2_1 et chap_2_2_2

On rajoute un Etat avec une contrainte budgétaire à l'équilibre à toutes les périodes
 cf chap_2_3_1 et chap2_3_2

On termine en introduisant un BGP
